function [ quaternion, state_estimate ] = relinearize( quaternion, state_estimate );
%
%
